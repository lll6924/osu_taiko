#ifndef WEAPON_HPP
#define WEAPON_HPP

const int WEAPON_SMALL = 0;
const int WEAPON_LARGE = 1;

#endif // WEAPON_HPP

