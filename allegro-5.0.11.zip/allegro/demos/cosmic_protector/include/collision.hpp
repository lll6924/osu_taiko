#ifndef COLLISION_HPP
#define COLLISION_HPP

bool checkCircleCollision(float x1, float y1, float r1,
   float x2, float y2, float r2);

#endif // COLLISION_HPP
